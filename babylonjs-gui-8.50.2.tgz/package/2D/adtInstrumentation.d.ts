import { PerfCounter } from "@babylonjs/core/Misc/perfCounter.js";
import type { IDisposable } from "@babylonjs/core/scene.js";
import type { AdvancedDynamicTexture } from "./advancedDynamicTexture.js";
/**
 * This class can be used to get instrumentation data from a AdvancedDynamicTexture object
 */
export declare class AdvancedDynamicTextureInstrumentation implements IDisposable {
    /**
     * Define the instrumented AdvancedDynamicTexture.
     */
    texture: AdvancedDynamicTexture;
    private _captureRenderTime;
    private _renderTime;
    private _captureLayoutTime;
    private _layoutTime;
    private _onBeginRenderObserver;
    private _onEndRenderObserver;
    private _onBeginLayoutObserver;
    private _onEndLayoutObserver;
    /**
     * Gets the perf counter used to capture render time
     */
    get renderTimeCounter(): PerfCounter;
    /**
     * Gets the perf counter used to capture layout time
     */
    get layoutTimeCounter(): PerfCounter;
    /**
     * Enable or disable the render time capture
     */
    get captureRenderTime(): boolean;
    set captureRenderTime(value: boolean);
    /**
     * Enable or disable the layout time capture
     */
    get captureLayoutTime(): boolean;
    set captureLayoutTime(value: boolean);
    /**
     * Instantiates a new advanced dynamic texture instrumentation.
     * This class can be used to get instrumentation data from an AdvancedDynamicTexture object
     * @param texture Defines the AdvancedDynamicTexture to instrument
     */
    constructor(
    /**
     * Define the instrumented AdvancedDynamicTexture.
     */
    texture: AdvancedDynamicTexture);
    /**
     * Dispose and release associated resources.
     */
    dispose(): void;
}
