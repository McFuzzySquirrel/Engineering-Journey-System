import { Observable } from "@babylonjs/core/Misc/observable.js";
import type { IDisposable } from "@babylonjs/core/scene.js";
import type { AdvancedDynamicTexture } from "./advancedDynamicTexture.js";
import { ValueAndUnit } from "./valueAndUnit.js";
/**
 * Define a style used by control to automatically setup properties based on a template.
 * Only support font related properties so far
 */
export declare class Style implements IDisposable {
    private _fontFamily;
    private _fontStyle;
    private _fontWeight;
    /** @internal */
    _host: AdvancedDynamicTexture;
    /** @internal */
    _fontSize: ValueAndUnit;
    /**
     * Observable raised when the style values are changed
     */
    onChangedObservable: Observable<Style>;
    /**
     * Creates a new style object
     * @param host defines the AdvancedDynamicTexture which hosts this style
     */
    constructor(host: AdvancedDynamicTexture);
    /**
     * Gets or sets the font size
     */
    get fontSize(): string | number;
    set fontSize(value: string | number);
    /**
     * Gets or sets the font family
     */
    get fontFamily(): string;
    set fontFamily(value: string);
    /**
     * Gets or sets the font style
     */
    get fontStyle(): string;
    set fontStyle(value: string);
    /** Gets or sets font weight */
    get fontWeight(): string;
    set fontWeight(value: string);
    /** Dispose all associated resources */
    dispose(): void;
}
