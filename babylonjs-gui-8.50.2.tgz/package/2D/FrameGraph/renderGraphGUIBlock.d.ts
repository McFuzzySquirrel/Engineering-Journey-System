import { NodeRenderGraphBlock } from "@babylonjs/core/FrameGraph/Node/nodeRenderGraphBlock.js";
import { AdvancedDynamicTexture } from "../advancedDynamicTexture.js";
import type { Scene } from "@babylonjs/core/scene.js";
import type { NodeRenderGraphConnectionPoint } from "@babylonjs/core/FrameGraph/Node/nodeRenderGraphBlockConnectionPoint.js";
import type { NodeRenderGraphBuildState } from "@babylonjs/core/FrameGraph/Node/nodeRenderGraphBuildState.js";
import { FrameGraphGUITask } from "./guiTask.js";
import type { FrameGraph } from "@babylonjs/core/FrameGraph/frameGraph.js";
/**
 * Block that implements a fullscreen GUI for render graph
 */
export declare class NodeRenderGraphGUIBlock extends NodeRenderGraphBlock {
    protected _frameGraphTask: FrameGraphGUITask;
    protected _gui: AdvancedDynamicTexture;
    /**
     * Gets the frame graph task associated with this block
     */
    get task(): FrameGraphGUITask;
    /**
     * Gets the GUI texture used by this block
     */
    get gui(): AdvancedDynamicTexture;
    /**
     * Create a new NodeRenderGraphGUIBlock
     * @param name defines the block name
     * @param frameGraph defines the hosting frame graph
     * @param scene defines the hosting scene
     */
    constructor(name: string, frameGraph: FrameGraph, scene: Scene);
    /**
     * Gets the current class name
     * @returns the class name
     */
    getClassName(): string;
    /**
     * Gets the target input component
     */
    get target(): NodeRenderGraphConnectionPoint;
    /**
     * Gets the output component
     */
    get output(): NodeRenderGraphConnectionPoint;
    protected _buildBlock(state: NodeRenderGraphBuildState): void;
}
