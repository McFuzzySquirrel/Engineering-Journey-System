import type { Nullable } from "@babylonjs/core/types.js";
import { Vector2 } from "@babylonjs/core/Maths/math.vector.js";
/**
 * Class used to transport Vector2 information for pointer events
 */
export declare class Vector2WithInfo extends Vector2 {
    /** defines the current mouse button index */
    buttonIndex: number;
    /**
     * Creates a new Vector2WithInfo
     * @param source defines the vector2 data to transport
     * @param buttonIndex defines the current mouse button index
     */
    constructor(source: Vector2, 
    /** defines the current mouse button index */
    buttonIndex?: number);
}
/** Class used to provide 2D matrix features */
export declare class Matrix2D {
    /** Gets the internal array of 6 floats used to store matrix data */
    m: Float32Array<ArrayBuffer>;
    /**
     * Creates a new matrix
     * @param m00 defines value for (0, 0)
     * @param m01 defines value for (0, 1)
     * @param m10 defines value for (1, 0)
     * @param m11 defines value for (1, 1)
     * @param m20 defines value for (2, 0)
     * @param m21 defines value for (2, 1)
     */
    constructor(m00: number, m01: number, m10: number, m11: number, m20: number, m21: number);
    /**
     * Fills the matrix from direct values
     * @param m00 defines value for (0, 0)
     * @param m01 defines value for (0, 1)
     * @param m10 defines value for (1, 0)
     * @param m11 defines value for (1, 1)
     * @param m20 defines value for (2, 0)
     * @param m21 defines value for (2, 1)
     * @returns the current modified matrix
     */
    fromValues(m00: number, m01: number, m10: number, m11: number, m20: number, m21: number): Matrix2D;
    /**
     * Gets matrix determinant
     * @returns the determinant
     */
    determinant(): number;
    /**
     * Inverses the matrix and stores it in a target matrix
     * @param result defines the target matrix
     * @returns the current matrix
     */
    invertToRef(result: Matrix2D): Matrix2D;
    /**
     * Multiplies the current matrix with another one
     * @param other defines the second operand
     * @param result defines the target matrix
     * @returns the current matrix
     */
    multiplyToRef(other: Matrix2D, result: Matrix2D): Matrix2D;
    /**
     * Applies the current matrix to a set of 2 floats and stores the result in a vector2
     * @param x defines the x coordinate to transform
     * @param y defines the x coordinate to transform
     * @param result defines the target vector2
     * @returns the current matrix
     */
    transformCoordinates(x: number, y: number, result: Vector2): Matrix2D;
    /**
     * Creates an identity matrix
     * @returns a new matrix
     */
    static Identity(): Matrix2D;
    /**
     * Creates an identity matrix and stores it in a target matrix
     * @param result defines the target matrix
     */
    static IdentityToRef(result: Matrix2D): void;
    /**
     * Creates a translation matrix and stores it in a target matrix
     * @param x defines the x coordinate of the translation
     * @param y defines the y coordinate of the translation
     * @param result defines the target matrix
     */
    static TranslationToRef(x: number, y: number, result: Matrix2D): void;
    /**
     * Creates a scaling matrix and stores it in a target matrix
     * @param x defines the x coordinate of the scaling
     * @param y defines the y coordinate of the scaling
     * @param result defines the target matrix
     */
    static ScalingToRef(x: number, y: number, result: Matrix2D): void;
    /**
     * Creates a rotation matrix and stores it in a target matrix
     * @param angle defines the rotation angle
     * @param result defines the target matrix
     */
    static RotationToRef(angle: number, result: Matrix2D): void;
    private static _TempPreTranslationMatrix;
    private static _TempPostTranslationMatrix;
    private static _TempRotationMatrix;
    private static _TempScalingMatrix;
    private static _TempCompose0;
    private static _TempCompose1;
    private static _TempCompose2;
    /**
     * Composes a matrix from translation, rotation, scaling and parent matrix and stores it in a target matrix
     * @param tx defines the x coordinate of the translation
     * @param ty defines the y coordinate of the translation
     * @param angle defines the rotation angle
     * @param scaleX defines the x coordinate of the scaling
     * @param scaleY defines the y coordinate of the scaling
     * @param parentMatrix defines the parent matrix to multiply by (can be null)
     * @param result defines the target matrix
     */
    static ComposeToRef(tx: number, ty: number, angle: number, scaleX: number, scaleY: number, parentMatrix: Nullable<Matrix2D>, result: Matrix2D): void;
}
/**
 * Useful math functions
 */
export declare class MathTools {
    /**
     * Default rounding precision for GUI elements. It should be
     * set to a power of ten, where the exponent means the number
     * of decimal digits to round to, i.e, 100 means 2 decimal digits,
     * 1000 means 3 decimal digits, etc. Default is 100 (2 decimal digits).
     */
    static DefaultRoundingPrecision: number;
    /**
     * Rounds a number to the nearest multiple of a given precision
     * @param value the value to be rounded
     * @param precision the multiple to which the value will be rounded. Default is 100 (2 decimal digits)
     * @returns
     */
    static Round(value: number, precision?: number): number;
}
