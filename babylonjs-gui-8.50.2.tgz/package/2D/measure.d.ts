import type { Matrix2D } from "./math2D.js";
/**
 * Class used to store 2D control sizes
 */
export declare class Measure {
    /** defines left coordinate */
    left: number;
    /** defines top coordinate  */
    top: number;
    /** defines width dimension  */
    width: number;
    /** defines height dimension */
    height: number;
    /**
     * Creates a new measure
     * @param left defines left coordinate
     * @param top defines top coordinate
     * @param width defines width dimension
     * @param height defines height dimension
     */
    constructor(
    /** defines left coordinate */
    left: number, 
    /** defines top coordinate  */
    top: number, 
    /** defines width dimension  */
    width: number, 
    /** defines height dimension */
    height: number);
    /**
     * Copy from another measure
     * @param other defines the other measure to copy from
     */
    copyFrom(other: Measure): void;
    /**
     * Copy from a group of 4 floats
     * @param left defines left coordinate
     * @param top defines top coordinate
     * @param width defines width dimension
     * @param height defines height dimension
     */
    copyFromFloats(left: number, top: number, width: number, height: number): void;
    /**
     * Computes the axis aligned bounding box measure for two given measures
     * @param a Input measure
     * @param b Input measure
     * @param result the resulting bounding measure
     */
    static CombineToRef(a: Measure, b: Measure, result: Measure): void;
    /**
     * Computes the axis aligned bounding box of the measure after it is modified by a given transform
     * @param transform the matrix to transform the measure before computing the AABB
     * @param addX number to add to left
     * @param addY number to add to top
     * @param addWidth number to add to width
     * @param addHeight number to add to height
     * @param result the resulting AABB
     */
    addAndTransformToRef(transform: Matrix2D, addX: number, addY: number, addWidth: number, addHeight: number, result: Measure): void;
    /**
     * Computes the axis aligned bounding box of the measure after it is modified by a given transform
     * @param transform the matrix to transform the measure before computing the AABB
     * @param result the resulting AABB
     */
    transformToRef(transform: Matrix2D, result: Measure): void;
    /**
     * Check equality between this measure and another one
     * @param other defines the other measures
     * @returns true if both measures are equals
     */
    isEqualsTo(other: Measure): boolean;
    /**
     * Creates an empty measure
     * @returns a new measure
     */
    static Empty(): Measure;
}
