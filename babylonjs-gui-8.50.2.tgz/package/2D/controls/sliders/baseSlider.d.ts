import { Observable } from "@babylonjs/core/Misc/observable.js";
import type { Vector2 } from "@babylonjs/core/Maths/math.vector.js";
import { Control } from "../control.js";
import { ValueAndUnit } from "../../valueAndUnit.js";
import type { PointerInfoBase } from "@babylonjs/core/Events/pointerEvents.js";
/**
 * Class used to create slider controls
 */
export declare class BaseSlider extends Control {
    name?: string | undefined;
    protected _thumbWidth: ValueAndUnit;
    private _minimum;
    private _maximum;
    private _value;
    private _isVertical;
    protected _barOffset: ValueAndUnit;
    private _isThumbClamped;
    protected _displayThumb: boolean;
    private _step;
    private _lastPointerDownId;
    protected _effectiveBarOffset: number;
    protected _renderLeft: number;
    protected _renderTop: number;
    protected _renderWidth: number;
    protected _renderHeight: number;
    protected _backgroundBoxLength: number;
    protected _backgroundBoxThickness: number;
    protected _effectiveThumbThickness: number;
    /** Observable raised when the slider value changes */
    onValueChangedObservable: Observable<number>;
    /** Gets or sets a boolean indicating if the thumb must be rendered */
    get displayThumb(): boolean;
    set displayThumb(value: boolean);
    /** Gets or sets a step to apply to values (0 by default) */
    get step(): number;
    set step(value: number);
    /** Gets or sets main bar offset (ie. the margin applied to the value bar) */
    get barOffset(): string | number;
    /** Gets main bar offset in pixels*/
    get barOffsetInPixels(): number;
    set barOffset(value: string | number);
    /** Gets or sets thumb width */
    get thumbWidth(): string | number;
    /** Gets thumb width in pixels */
    get thumbWidthInPixels(): number;
    set thumbWidth(value: string | number);
    /** Gets or sets minimum value */
    get minimum(): number;
    set minimum(value: number);
    /** Gets or sets maximum value */
    get maximum(): number;
    set maximum(value: number);
    /** Gets or sets current value */
    get value(): number;
    set value(value: number);
    /**Gets or sets a boolean indicating if the slider should be vertical or horizontal */
    get isVertical(): boolean;
    set isVertical(value: boolean);
    /** Gets or sets a value indicating if the thumb can go over main bar extends */
    get isThumbClamped(): boolean;
    set isThumbClamped(value: boolean);
    /**
     * Creates a new BaseSlider
     * @param name defines the control name
     */
    constructor(name?: string | undefined);
    protected _getTypeName(): string;
    protected _getThumbPosition(): number;
    protected _getThumbThickness(type: string): number;
    protected _prepareRenderingData(type: string): void;
    private _pointerIsDown;
    /**
     * @internal
     */
    protected _updateValueFromPointer(x: number, y: number): void;
    _onPointerDown(target: Control, coordinates: Vector2, pointerId: number, buttonIndex: number, pi: PointerInfoBase): boolean;
    _onPointerMove(target: Control, coordinates: Vector2, pointerId: number, pi: PointerInfoBase): void;
    _onPointerUp(target: Control, coordinates: Vector2, pointerId: number, buttonIndex: number, notifyClick: boolean): void;
    _onCanvasBlur(): void;
}
