import type { Nullable } from "@babylonjs/core/types.js";
import { Observable } from "@babylonjs/core/Misc/observable.js";
import type { Vector2 } from "@babylonjs/core/Maths/math.vector.js";
import { Control } from "./control.js";
import type { VirtualKeyboard } from "./virtualKeyboard.js";
import type { Measure } from "../measure.js";
import { InputText } from "./inputText.js";
import type { ICanvasRenderingContext } from "@babylonjs/core/Engines/ICanvas.js";
import type { PointerInfo, PointerInfoBase } from "@babylonjs/core/Events/pointerEvents.js";
import type { IKeyboardEvent } from "@babylonjs/core/Events/deviceInputEvents.js";
/**
 * Class used to create input text control
 */
export declare class InputTextArea extends InputText {
    name?: string | undefined;
    private _textHorizontalAlignment;
    private _textVerticalAlignment;
    private _prevText;
    private _lines;
    private _lineSpacing;
    private _maxHeight;
    private _clipTextTop;
    private _clipTextLeft;
    private _cursorInfo;
    private _highlightCursorInfo;
    /**
     * An event triggered after the text was broken up into lines
     */
    onLinesReadyObservable: Observable<InputTextArea>;
    /** @internal */
    _connectedVirtualKeyboard: Nullable<VirtualKeyboard>;
    private _contextForBreakLines;
    private _clickedCoordinateX;
    private _clickedCoordinateY;
    private _availableWidth;
    private _availableHeight;
    private _scrollTop;
    private _autoStretchHeight;
    /** Gets or sets a boolean indicating if the control can auto stretch its height to adapt to the text */
    get autoStretchHeight(): boolean;
    set autoStretchHeight(value: boolean);
    set height(value: string | number);
    get maxHeight(): string | number;
    /** Gets the maximum width allowed by the control in pixels */
    get maxHeightInPixels(): number;
    set maxHeight(value: string | number);
    /**
     * Creates a new InputTextArea
     * @param name defines the control name
     * @param text defines the text of the control
     */
    constructor(name?: string | undefined, text?: string);
    protected _getTypeName(): string;
    /**
     * Handles the keyboard event
     * @param evt Defines the KeyboardEvent
     */
    processKeyboard(evt: IKeyboardEvent): void;
    /**
     * Process the last keyboard input
     *
     * @param code The ascii input number
     * @param key The key string representation
     * @param evt The keyboard event emits with input
     * @internal
     */
    alternativeProcessKey(code: string, key?: string, evt?: IKeyboardEvent): void;
    protected _parseLineWordWrap(line: string | undefined, width: number, context: ICanvasRenderingContext): {
        text: string;
        width: number;
        lineEnding: string;
    }[];
    protected _breakLines(refWidth: number, context: ICanvasRenderingContext): object[];
    protected _parseLine(line: string | undefined, context: ICanvasRenderingContext): {
        text: string;
        width: number;
        lineEnding: string;
    };
    /**
     * Processing of child right before the parent measurement update
     *
     * @param parentMeasure The parent measure
     * @param context The rendering canvas
     * @internal
     */
    protected _preMeasure(parentMeasure: Measure, context: ICanvasRenderingContext): void;
    protected _textHasChanged(): void;
    private _computeScroll;
    /**
     * Processing of child after the parent measurement update
     *
     * @internal
     */
    protected _additionalProcessing(): void;
    private _drawText;
    /**
     * Copy the text in the clipboard
     *
     * @param ev The clipboard event
     * @internal
     */
    protected _onCopyText(ev: ClipboardEvent): void;
    /**
     * Cut the text and copy it in the clipboard
     *
     * @param ev The clipboard event
     * @internal
     */
    protected _onCutText(ev: ClipboardEvent): void;
    /**
     * Paste the copied text from the clipboard
     *
     * @param ev The clipboard event
     * @internal
     */
    protected _onPasteText(ev: ClipboardEvent): void;
    _draw(context: ICanvasRenderingContext): void;
    private _resetBlinking;
    _onPointerDown(target: Control, coordinates: Vector2, pointerId: number, buttonIndex: number, pi: PointerInfoBase): boolean;
    _onPointerMove(target: Control, coordinates: Vector2, pointerId: number, pi: PointerInfoBase): void;
    /**
     * Apply the correct position of cursor according to current modification
     */
    private _updateCursorPosition;
    /**
     * Update all values of cursor information based on cursorIndex value
     *
     * @param offset The index to take care of
     * @internal
     */
    protected _updateValueFromCursorIndex(offset: number): void;
    /**
     * Select the word immediatly under the cursor on double click
     *
     * @param _evt Pointer informations of double click
     * @internal
     */
    protected _processDblClick(_evt: PointerInfo): void;
    /** @internal */
    selectAllText(): void;
    dispose(): void;
}
