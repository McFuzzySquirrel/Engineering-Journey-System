import { Control } from "./control.js";
import type { ICanvasRenderingContext } from "@babylonjs/core/Engines/ICanvas.js";
/** Class used to render a grid  */
export declare class DisplayGrid extends Control {
    name?: string | undefined;
    private _cellWidth;
    private _cellHeight;
    private _minorLineTickness;
    private _minorLineColor;
    private _majorLineTickness;
    private _majorLineColor;
    private _majorLineFrequency;
    private _background;
    private _displayMajorLines;
    private _displayMinorLines;
    /** Gets or sets a boolean indicating if minor lines must be rendered (true by default)) */
    get displayMinorLines(): boolean;
    set displayMinorLines(value: boolean);
    /** Gets or sets a boolean indicating if major lines must be rendered (true by default)) */
    get displayMajorLines(): boolean;
    set displayMajorLines(value: boolean);
    /** Gets or sets background color (Black by default) */
    get background(): string;
    set background(value: string);
    /** Gets or sets the width of each cell (20 by default) */
    get cellWidth(): number;
    set cellWidth(value: number);
    /** Gets or sets the height of each cell (20 by default) */
    get cellHeight(): number;
    set cellHeight(value: number);
    /** Gets or sets the tickness of minor lines (1 by default) */
    get minorLineTickness(): number;
    set minorLineTickness(value: number);
    /** Gets or sets the color of minor lines (DarkGray by default) */
    get minorLineColor(): string;
    set minorLineColor(value: string);
    /** Gets or sets the tickness of major lines (2 by default) */
    get majorLineTickness(): number;
    set majorLineTickness(value: number);
    /** Gets or sets the color of major lines (White by default) */
    get majorLineColor(): string;
    set majorLineColor(value: string);
    /** Gets or sets the frequency of major lines (default is 1 every 5 minor lines)*/
    get majorLineFrequency(): number;
    set majorLineFrequency(value: number);
    /**
     * Creates a new GridDisplayRectangle
     * @param name defines the control name
     */
    constructor(name?: string | undefined);
    _draw(context: ICanvasRenderingContext): void;
    protected _getTypeName(): string;
}
