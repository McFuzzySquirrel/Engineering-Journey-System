import type { Nullable } from "@babylonjs/core/types.js";
import { Control } from "./control.js";
import { Measure } from "../measure.js";
import type { AdvancedDynamicTexture } from "../advancedDynamicTexture.js";
import type { PointerInfoBase } from "@babylonjs/core/Events/pointerEvents.js";
import type { ICanvasRenderingContext } from "@babylonjs/core/Engines/ICanvas.js";
import { DynamicTexture } from "@babylonjs/core/Materials/Textures/dynamicTexture.js";
import { Observable } from "@babylonjs/core/Misc/observable.js";
import type { BaseGradient } from "./gradient/BaseGradient.js";
/**
 * Root class for 2D containers
 * @see https://doc.babylonjs.com/features/featuresDeepDive/gui/gui#containers
 */
export declare class Container extends Control {
    name?: string | undefined;
    /** @internal */
    _children: Control[];
    /** @internal */
    protected _measureForChildren: Measure;
    /** @internal */
    protected _background: string;
    /** @internal */
    protected _backgroundGradient: Nullable<BaseGradient>;
    /** @internal */
    protected _adaptWidthToChildren: boolean;
    /** @internal */
    protected _adaptHeightToChildren: boolean;
    /** @internal */
    protected _renderToIntermediateTexture: boolean;
    /** @internal */
    protected _intermediateTexture: Nullable<DynamicTexture>;
    /**
     * Gets or sets a boolean indicating that the container will let internal controls handle picking instead of doing it directly using its bounding info
     */
    delegatePickingToChildren: boolean;
    /** Gets or sets boolean indicating if children should be rendered to an intermediate texture rather than directly to host, useful for alpha blending */
    get renderToIntermediateTexture(): boolean;
    set renderToIntermediateTexture(value: boolean);
    /**
     * Gets or sets a boolean indicating that layout cycle errors should be displayed on the console
     */
    logLayoutCycleErrors: boolean;
    /**
     * Gets or sets the number of layout cycles (a change involved by a control while evaluating the layout) allowed
     */
    maxLayoutCycle: number;
    /** Gets or sets a boolean indicating if the container should try to adapt to its children height */
    get adaptHeightToChildren(): boolean;
    set adaptHeightToChildren(value: boolean);
    /** Gets or sets a boolean indicating if the container should try to adapt to its children width */
    get adaptWidthToChildren(): boolean;
    set adaptWidthToChildren(value: boolean);
    /** Gets or sets background color */
    get background(): string;
    set background(value: string);
    /** Gets or sets background gradient color. Takes precedence over background */
    get backgroundGradient(): Nullable<BaseGradient>;
    set backgroundGradient(value: Nullable<BaseGradient>);
    /** Gets the list of children */
    get children(): Control[];
    get isReadOnly(): boolean;
    set isReadOnly(value: boolean);
    /**
     * Creates a new Container
     * @param name defines the name of the container
     */
    constructor(name?: string | undefined);
    protected _getTypeName(): string;
    _flagDescendantsAsMatrixDirty(): void;
    /**
     * Gets a child using its name
     * @param name defines the child name to look for
     * @returns the child control if found
     */
    getChildByName(name: string): Nullable<Control>;
    /**
     * Gets a child using its type and its name
     * @param name defines the child name to look for
     * @param type defines the child type to look for
     * @returns the child control if found
     */
    getChildByType(name: string, type: string): Nullable<Control>;
    /**
     * Search for a specific control in children
     * @param control defines the control to look for
     * @returns true if the control is in child list
     */
    containsControl(control: Control): boolean;
    /**
     * Adds a new control to the current container
     * @param control defines the control to add
     * @returns the current container
     */
    addControl(control: Nullable<Control>): Container;
    /**
     * Removes all controls from the current container
     * @returns the current container
     */
    clearControls(): Container;
    /**
     * Removes a control from the current container
     * @param control defines the control to remove
     * @returns the current container
     */
    removeControl(control: Control): Container;
    /**
     * An event triggered when any control is added to this container.
     */
    onControlAddedObservable: Observable<Nullable<Control>>;
    /**
     * An event triggered when any control is removed from this container.
     */
    onControlRemovedObservable: Observable<Nullable<Control>>;
    /**
     * @internal
     */
    _reOrderControl(control: Control): void;
    /**
     * @internal
     */
    _offsetLeft(offset: number): void;
    /**
     * @internal
     */
    _offsetTop(offset: number): void;
    /** @internal */
    _markAllAsDirty(): void;
    protected _getBackgroundColor(context: ICanvasRenderingContext): string | CanvasGradient;
    /**
     * @internal
     */
    protected _localDraw(context: ICanvasRenderingContext): void;
    /**
     * @internal
     */
    _link(host: AdvancedDynamicTexture): void;
    /** @internal */
    protected _beforeLayout(): void;
    /**
     * @internal
     */
    protected _processMeasures(parentMeasure: Measure, context: ICanvasRenderingContext): void;
    /**
     * @internal
     */
    _layout(parentMeasure: Measure, context: ICanvasRenderingContext): boolean;
    protected _postMeasure(): void;
    private _inverseTransformMatrix;
    private _inverseMeasure;
    /**
     * @internal
     */
    _draw(context: ICanvasRenderingContext, invalidatedRectangle?: Measure): void;
    getDescendantsToRef(results: Control[], directDescendantsOnly?: boolean, predicate?: (control: Control) => boolean): void;
    /**
     * @internal
     */
    _processPicking(x: number, y: number, pi: Nullable<PointerInfoBase>, type: number, pointerId: number, buttonIndex: number, deltaX?: number, deltaY?: number): boolean;
    /**
     * @internal
     */
    protected _additionalProcessing(parentMeasure: Measure, context: ICanvasRenderingContext): void;
    protected _getAdaptDimTo(dim: "width" | "height"): boolean;
    isDimensionFullyDefined(dim: "width" | "height"): boolean;
    /**
     * Serializes the current control
     * @param serializationObject defined the JSON serialized object
     * @param force force serialization even if isSerializable === false
     * @param allowCanvas defines if the control is allowed to use a Canvas2D object to serialize (true by default)
     */
    serialize(serializationObject: any, force?: boolean, allowCanvas?: boolean): void;
    /** Releases associated resources */
    dispose(): void;
    /**
     * @internal
     */
    _parseFromContent(serializedObject: any, host: AdvancedDynamicTexture, urlRewriter?: (url: string) => string): void;
    isReady(): boolean;
}
