import { Rectangle } from "./rectangle.js";
import { StackPanel } from "./stackPanel.js";
/** Class used to create a RadioGroup
 * which contains groups of radio buttons
 */
export declare class SelectorGroup {
    /** name of SelectorGroup */
    name: string;
    private _groupPanel;
    private _selectors;
    private _groupHeader;
    /**
     * Creates a new SelectorGroup
     * @param name of group, used as a group heading
     */
    constructor(
    /** name of SelectorGroup */
    name: string);
    /** Gets the groupPanel of the SelectorGroup  */
    get groupPanel(): StackPanel;
    /** Gets the selectors array */
    get selectors(): StackPanel[];
    /** Gets and sets the group header */
    get header(): string;
    set header(label: string);
    /**
     * @internal
     */
    private _addGroupHeader;
    /**
     * @internal
     */
    _getSelector(selectorNb: number): StackPanel | undefined;
    /** Removes the selector at the given position
     * @param selectorNb the position of the selector within the group
     */
    removeSelector(selectorNb: number): void;
}
/** Class used to create a CheckboxGroup
 * which contains groups of checkbox buttons
 */
export declare class CheckboxGroup extends SelectorGroup {
    /** Adds a checkbox as a control
     * @param text is the label for the selector
     * @param func is the function called when the Selector is checked
     * @param checked is true when Selector is checked
     */
    addCheckbox(text: string, func?: (s: boolean) => void, checked?: boolean): void;
    /**
     * @internal
     */
    _setSelectorLabel(selectorNb: number, label: string): void;
    /**
     * @internal
     */
    _setSelectorLabelColor(selectorNb: number, color: string): void;
    /**
     * @internal
     */
    _setSelectorButtonColor(selectorNb: number, color: string): void;
    /**
     * @internal
     */
    _setSelectorButtonBackground(selectorNb: number, color: string): void;
}
/** Class used to create a RadioGroup
 * which contains groups of radio buttons
 */
export declare class RadioGroup extends SelectorGroup {
    private _selectNb;
    /** Adds a radio button as a control
     * @param label is the label for the selector
     * @param func is the function called when the Selector is checked
     * @param checked is true when Selector is checked
     */
    addRadio(label: string, func?: (n: number) => void, checked?: boolean): void;
    /**
     * @internal
     */
    _setSelectorLabel(selectorNb: number, label: string): void;
    /**
     * @internal
     */
    _setSelectorLabelColor(selectorNb: number, color: string): void;
    /**
     * @internal
     */
    _setSelectorButtonColor(selectorNb: number, color: string): void;
    /**
     * @internal
     */
    _setSelectorButtonBackground(selectorNb: number, color: string): void;
}
/** Class used to create a SliderGroup
 * which contains groups of slider buttons
 */
export declare class SliderGroup extends SelectorGroup {
    /**
     * Adds a slider to the SelectorGroup
     * @param label is the label for the SliderBar
     * @param func is the function called when the Slider moves
     * @param unit is a string describing the units used, eg degrees or metres
     * @param min is the minimum value for the Slider
     * @param max is the maximum value for the Slider
     * @param value is the start value for the Slider between min and max
     * @param onValueChange is the function used to format the value displayed, eg radians to degrees
     */
    addSlider(label: string, func?: (v: number) => void, unit?: string, min?: number, max?: number, value?: number, onValueChange?: (v: number) => number): void;
    /**
     * @internal
     */
    _setSelectorLabel(selectorNb: number, label: string): void;
    /**
     * @internal
     */
    _setSelectorLabelColor(selectorNb: number, color: string): void;
    /**
     * @internal
     */
    _setSelectorButtonColor(selectorNb: number, color: string): void;
    /**
     * @internal
     */
    _setSelectorButtonBackground(selectorNb: number, color: string): void;
}
/** Class used to hold the controls for the checkboxes, radio buttons and sliders
 * @see https://doc.babylonjs.com/features/featuresDeepDive/gui/selector
 */
export declare class SelectionPanel extends Rectangle {
    /** name of SelectionPanel */
    name: string;
    /** an array of SelectionGroups */
    groups: SelectorGroup[];
    private _panel;
    private _buttonColor;
    private _buttonBackground;
    private _headerColor;
    private _barColor;
    private _barHeight;
    private _spacerHeight;
    private _labelColor;
    private _groups;
    private _bars;
    /**
     * Creates a new SelectionPanel
     * @param name of SelectionPanel
     * @param groups is an array of SelectionGroups
     */
    constructor(
    /** name of SelectionPanel */
    name: string, 
    /** an array of SelectionGroups */
    groups?: SelectorGroup[]);
    protected _getTypeName(): string;
    /** Gets the (stack) panel of the SelectionPanel  */
    get panel(): StackPanel;
    /** Gets or sets the headerColor */
    get headerColor(): string;
    set headerColor(color: string);
    private _setHeaderColor;
    /** Gets or sets the button color */
    get buttonColor(): string;
    set buttonColor(color: string);
    private _setbuttonColor;
    /** Gets or sets the label color */
    get labelColor(): string;
    set labelColor(color: string);
    private _setLabelColor;
    /** Gets or sets the button background */
    get buttonBackground(): string;
    set buttonBackground(color: string);
    private _setButtonBackground;
    /** Gets or sets the color of separator bar */
    get barColor(): string;
    set barColor(color: string);
    private _setBarColor;
    /** Gets or sets the height of separator bar */
    get barHeight(): string;
    set barHeight(value: string);
    private _setBarHeight;
    /** Gets or sets the height of spacers*/
    get spacerHeight(): string;
    set spacerHeight(value: string);
    private _setSpacerHeight;
    /** Adds a bar between groups */
    private _addSpacer;
    /** Add a group to the selection panel
     * @param group is the selector group to add
     */
    addGroup(group: SelectorGroup): void;
    /** Remove the group from the given position
     * @param groupNb is the position of the group in the list
     */
    removeGroup(groupNb: number): void;
    /** Change a group header label
     * @param label is the new group header label
     * @param groupNb is the number of the group to relabel
     * */
    setHeaderName(label: string, groupNb: number): void;
    /** Change selector label to the one given
     * @param label is the new selector label
     * @param groupNb is the number of the groupcontaining the selector
     * @param selectorNb is the number of the selector within a group to relabel
     * */
    relabel(label: string, groupNb: number, selectorNb: number): void;
    /** For a given group position remove the selector at the given position
     * @param groupNb is the number of the group to remove the selector from
     * @param selectorNb is the number of the selector within the group
     */
    removeFromGroupSelector(groupNb: number, selectorNb: number): void;
    /** For a given group position of correct type add a checkbox button
     * @param groupNb is the number of the group to remove the selector from
     * @param label is the label for the selector
     * @param func is the function called when the Selector is checked
     * @param checked is true when Selector is checked
     */
    addToGroupCheckbox(groupNb: number, label: string, func?: () => void, checked?: boolean): void;
    /** For a given group position of correct type add a radio button
     * @param groupNb is the number of the group to remove the selector from
     * @param label is the label for the selector
     * @param func is the function called when the Selector is checked
     * @param checked is true when Selector is checked
     */
    addToGroupRadio(groupNb: number, label: string, func?: () => void, checked?: boolean): void;
    /**
     * For a given slider group add a slider
     * @param groupNb is the number of the group to add the slider to
     * @param label is the label for the Slider
     * @param func is the function called when the Slider moves
     * @param unit is a string describing the units used, eg degrees or metres
     * @param min is the minimum value for the Slider
     * @param max is the maximum value for the Slider
     * @param value is the start value for the Slider between min and max
     * @param onVal is the function used to format the value displayed, eg radians to degrees
     */
    addToGroupSlider(groupNb: number, label: string, func?: () => void, unit?: string, min?: number, max?: number, value?: number, onVal?: (v: number) => number): void;
}
