import { Container } from "./container.js";
import type { Measure } from "../measure.js";
import type { AdvancedDynamicTexture } from "../advancedDynamicTexture.js";
import type { ICanvasRenderingContext } from "@babylonjs/core/Engines/ICanvas.js";
/**
 * Class used to create a 2D stack panel container
 */
export declare class StackPanel extends Container {
    name?: string | undefined;
    private _isVertical;
    private _manualWidth;
    private _manualHeight;
    private _doNotTrackManualChanges;
    private _spacing;
    /**
     * Gets or sets a boolean indicating that layout warnings should be ignored
     */
    ignoreLayoutWarnings: boolean;
    /** Gets or sets a boolean indicating if the stack panel is vertical or horizontal*/
    get isVertical(): boolean;
    set isVertical(value: boolean);
    /**
     * Gets or sets the spacing (in pixels) between each child.
     */
    get spacing(): number;
    set spacing(value: number);
    /**
     * Gets or sets panel width.
     * This value should not be set when in horizontal mode as it will be computed automatically
     */
    set width(value: string | number);
    get width(): string | number;
    /**
     * Gets or sets panel height.
     * This value should not be set when in vertical mode as it will be computed automatically
     */
    set height(value: string | number);
    get height(): string | number;
    /**
     * Creates a new StackPanel
     * @param name defines control name
     */
    constructor(name?: string | undefined);
    protected _getTypeName(): string;
    /**
     * @internal
     */
    protected _preMeasure(parentMeasure: Measure, context: ICanvasRenderingContext): void;
    protected _additionalProcessing(parentMeasure: Measure, context: ICanvasRenderingContext): void;
    protected _postMeasure(): void;
    private _getManualDim;
    isDimensionFullyDefined(dim: "width" | "height"): boolean;
    /**
     * Serializes the current control
     * @param serializationObject defined the JSON serialized object
     * @param force force serialization even if isSerializable === false
     * @param allowCanvas defines if the control is allowed to use a Canvas2D object to serialize
     */
    serialize(serializationObject: any, force: boolean, allowCanvas: boolean): void;
    /**
     * @internal
     */
    _parseFromContent(serializedObject: any, host: AdvancedDynamicTexture): void;
}
