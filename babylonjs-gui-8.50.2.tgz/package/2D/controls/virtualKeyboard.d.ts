import type { Nullable } from "@babylonjs/core/types.js";
import { Observable } from "@babylonjs/core/Misc/observable.js";
import { StackPanel } from "./stackPanel.js";
import type { InputText } from "./inputText.js";
import type { AdvancedDynamicTexture } from "../advancedDynamicTexture.js";
import { InputTextArea } from "./inputTextArea.js";
/**
 * Class used to store key control properties
 */
export declare class KeyPropertySet {
    /** Width */
    width?: string;
    /** Height */
    height?: string;
    /** Left padding */
    paddingLeft?: string;
    /** Right padding */
    paddingRight?: string;
    /** Top padding */
    paddingTop?: string;
    /** Bottom padding */
    paddingBottom?: string;
    /** Foreground color */
    color?: string;
    /** Background color */
    background?: string;
}
/**
 * Class used to create virtual keyboard
 */
export declare class VirtualKeyboard extends StackPanel {
    /** Observable raised when a key is pressed */
    onKeyPressObservable: Observable<string>;
    /** Gets or sets default key button width */
    defaultButtonWidth: string;
    /** Gets or sets default key button height */
    defaultButtonHeight: string;
    /** Gets or sets default key button left padding */
    defaultButtonPaddingLeft: string;
    /** Gets or sets default key button right padding */
    defaultButtonPaddingRight: string;
    /** Gets or sets default key button top padding */
    defaultButtonPaddingTop: string;
    /** Gets or sets default key button bottom padding */
    defaultButtonPaddingBottom: string;
    /** Gets or sets default key button foreground color */
    defaultButtonColor: string;
    /** Gets or sets default key button background color */
    defaultButtonBackground: string;
    /** Gets or sets shift button foreground color */
    shiftButtonColor: string;
    /** Gets or sets shift button thickness*/
    selectedShiftThickness: number;
    /** Gets shift key state */
    shiftState: number;
    protected _getTypeName(): string;
    private _createKey;
    /**
     * Adds a new row of keys
     * @param keys defines the list of keys to add
     * @param propertySets defines the associated property sets
     */
    addKeysRow(keys: Array<string>, propertySets?: Array<KeyPropertySet>): void;
    /**
     * Set the shift key to a specific state
     * @param shiftState defines the new shift state
     */
    applyShiftState(shiftState: number): void;
    private _currentlyConnectedInputText;
    private _connectedInputTexts;
    private _onKeyPressObserver;
    /** Gets the input text control currently attached to the keyboard */
    get connectedInputText(): Nullable<InputText | InputTextArea>;
    /**
     * Connects the keyboard with an input text control
     *
     * @param input defines the target control
     */
    connect(input: InputText): void;
    /**
     * Disconnects the keyboard from connected InputText controls
     *
     * @param input optionally defines a target control, otherwise all are disconnected
     */
    disconnect(input?: InputText): void;
    private _removeConnectedInputObservables;
    /**
     * Release all resources
     */
    dispose(): void;
    /**
     * Creates a new keyboard using a default layout
     *
     * @param name defines control name
     * @returns a new VirtualKeyboard
     */
    static CreateDefaultLayout(name?: string): VirtualKeyboard;
    /**
     * @internal
     */
    _parseFromContent(serializedObject: any, host: AdvancedDynamicTexture): void;
}
