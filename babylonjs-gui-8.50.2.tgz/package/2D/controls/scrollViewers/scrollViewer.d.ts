import type { Nullable } from "@babylonjs/core/types.js";
import { Rectangle } from "../rectangle.js";
import type { Image } from "../image.js";
import { Control } from "../control.js";
import type { Container } from "../container.js";
import type { Measure } from "../../measure.js";
import type { AdvancedDynamicTexture } from "../../advancedDynamicTexture.js";
import { ScrollBar } from "../sliders/scrollBar.js";
import { ImageScrollBar } from "../sliders/imageScrollBar.js";
import type { ICanvasRenderingContext } from "@babylonjs/core/Engines/ICanvas.js";
/**
 * Class used to hold a viewer window and sliders in a grid
 */
export declare class ScrollViewer extends Rectangle {
    private _grid;
    private _horizontalBarSpace;
    private _verticalBarSpace;
    private _dragSpace;
    private _horizontalBar;
    private _verticalBar;
    private _barColor;
    private _barBackground;
    private _barImage;
    private _horizontalBarImage;
    private _verticalBarImage;
    private _barBackgroundImage;
    private _horizontalBarBackgroundImage;
    private _verticalBarBackgroundImage;
    private _barSize;
    private _window;
    private _pointerIsOver;
    private _wheelPrecision;
    private _onWheelObserver;
    private _clientWidth;
    private _clientHeight;
    private _useImageBar;
    private _thumbLength;
    private _thumbHeight;
    private _barImageHeight;
    private _horizontalBarImageHeight;
    private _verticalBarImageHeight;
    private _oldWindowContentsWidth;
    private _oldWindowContentsHeight;
    /**
     * Gets the horizontal scrollbar
     */
    get horizontalBar(): ScrollBar | ImageScrollBar;
    /**
     * Gets the vertical scrollbar
     */
    get verticalBar(): ScrollBar | ImageScrollBar;
    /**
     * Adds a new control to the current container
     * @param control defines the control to add
     * @returns the current container
     */
    addControl(control: Nullable<Control>): Container;
    /**
     * Removes a control from the current container
     * @param control defines the control to remove
     * @returns the current container
     */
    removeControl(control: Control): Container;
    /** Gets the list of children */
    get children(): Control[];
    _flagDescendantsAsMatrixDirty(): void;
    /**
     * Freezes or unfreezes the controls in the window.
     * When controls are frozen, the scroll viewer can render a lot more quickly but updates to positions/sizes of controls
     * are not taken into account. If you want to change positions/sizes, unfreeze, perform the changes then freeze again
     */
    get freezeControls(): boolean;
    set freezeControls(value: boolean);
    /** Gets the bucket width */
    get bucketWidth(): number;
    /** Gets the bucket height */
    get bucketHeight(): number;
    /**
     * Sets the bucket sizes.
     * When freezeControls is true, setting a non-zero bucket size will improve performances by updating only
     * controls that are visible. The bucket sizes is used to subdivide (internally) the window area to smaller areas into which
     * controls are dispatched. So, the size should be roughly equals to the mean size of all the controls of
     * the window. To disable the usage of buckets, sets either width or height (or both) to 0.
     * Please note that using this option will raise the memory usage (the higher the bucket sizes, the less memory
     * used), that's why it is not enabled by default.
     * @param width width of the bucket
     * @param height height of the bucket
     */
    setBucketSizes(width: number, height: number): void;
    private _forceHorizontalBar;
    private _forceVerticalBar;
    /**
     * Forces the horizontal scroll bar to be displayed
     */
    get forceHorizontalBar(): boolean;
    set forceHorizontalBar(value: boolean);
    /**
     * Forces the vertical scroll bar to be displayed
     */
    get forceVerticalBar(): boolean;
    set forceVerticalBar(value: boolean);
    /**
     * Creates a new ScrollViewer
     * @param name of ScrollViewer
     * @param isImageBased
     */
    constructor(name?: string, isImageBased?: boolean);
    /** Reset the scroll viewer window to initial size */
    resetWindow(): void;
    protected _getTypeName(): string;
    private _buildClientSizes;
    protected _additionalProcessing(parentMeasure: Measure, context: ICanvasRenderingContext): void;
    protected _postMeasure(): void;
    /**
     * Gets or sets the mouse wheel precision
     * from 0 to 1 with a default value of 0.05
     * */
    get wheelPrecision(): number;
    set wheelPrecision(value: number);
    /** Gets or sets the scroll bar container background color */
    get scrollBackground(): string;
    set scrollBackground(color: string);
    /** Gets or sets the bar color */
    get barColor(): string;
    set barColor(color: string);
    /** Gets or sets the bar image */
    get thumbImage(): Image;
    set thumbImage(value: Image);
    /** Gets or sets the horizontal bar image */
    get horizontalThumbImage(): Image;
    set horizontalThumbImage(value: Image);
    /** Gets or sets the vertical bar image */
    get verticalThumbImage(): Image;
    set verticalThumbImage(value: Image);
    /** Gets or sets the size of the bar */
    get barSize(): number;
    set barSize(value: number);
    /** Gets or sets the length of the thumb */
    get thumbLength(): number;
    set thumbLength(value: number);
    /** Gets or sets the height of the thumb */
    get thumbHeight(): number;
    set thumbHeight(value: number);
    /** Gets or sets the height of the bar image */
    get barImageHeight(): number;
    set barImageHeight(value: number);
    /** Gets or sets the height of the horizontal bar image */
    get horizontalBarImageHeight(): number;
    set horizontalBarImageHeight(value: number);
    /** Gets or sets the height of the vertical bar image */
    get verticalBarImageHeight(): number;
    set verticalBarImageHeight(value: number);
    /** Gets or sets the bar background */
    get barBackground(): string;
    set barBackground(color: string);
    /** Gets or sets the bar background image */
    get barImage(): Image;
    set barImage(value: Image);
    /** Gets or sets the horizontal bar background image */
    get horizontalBarImage(): Image;
    set horizontalBarImage(value: Image);
    /** Gets or sets the vertical bar background image */
    get verticalBarImage(): Image;
    set verticalBarImage(value: Image);
    private _setWindowPosition;
    /** @internal */
    private _updateScroller;
    _link(host: AdvancedDynamicTexture): void;
    /**
     * @internal
     */
    private _addBar;
    /** @internal */
    private _attachWheel;
    _renderHighlightSpecific(context: ICanvasRenderingContext): void;
    /** Releases associated resources */
    dispose(): void;
}
