import { Observable } from "@babylonjs/core/Misc/observable.js";
import type { Vector2 } from "@babylonjs/core/Maths/math.vector.js";
import { Control } from "./control.js";
import { StackPanel } from "./stackPanel.js";
import type { PointerInfoBase } from "@babylonjs/core/Events/pointerEvents.js";
import type { ICanvasRenderingContext } from "@babylonjs/core/Engines/ICanvas.js";
/**
 * Class used to represent a 2D checkbox
 */
export declare class Checkbox extends Control {
    name?: string | undefined;
    private _isChecked;
    private _background;
    private _checkSizeRatio;
    private _thickness;
    /** Gets or sets border thickness  */
    get thickness(): number;
    set thickness(value: number);
    /**
     * Observable raised when isChecked property changes
     */
    onIsCheckedChangedObservable: Observable<boolean>;
    /** Gets or sets a value indicating the ratio between overall size and check size */
    get checkSizeRatio(): number;
    set checkSizeRatio(value: number);
    /** Gets or sets background color */
    get background(): string;
    set background(value: string);
    /** Gets or sets a boolean indicating if the checkbox is checked or not */
    get isChecked(): boolean;
    set isChecked(value: boolean);
    /**
     * Creates a new CheckBox
     * @param name defines the control name
     */
    constructor(name?: string | undefined);
    protected _getTypeName(): string;
    /**
     * @internal
     */
    _draw(context: ICanvasRenderingContext): void;
    /**
     * @internal
     */
    _onPointerDown(target: Control, coordinates: Vector2, pointerId: number, buttonIndex: number, pi: PointerInfoBase): boolean;
    /**
     * Utility function to easily create a checkbox with a header
     * @param title defines the label to use for the header
     * @param onValueChanged defines the callback to call when value changes
     * @returns a StackPanel containing the checkbox and a textBlock
     */
    static AddCheckBoxWithHeader(title: string, onValueChanged: (value: boolean) => void): StackPanel;
}
