import { Observable } from "@babylonjs/core/Misc/observable.js";
import type { Vector2 } from "@babylonjs/core/Maths/math.vector.js";
import { Control } from "./control.js";
import { StackPanel } from "./stackPanel.js";
import type { PointerInfoBase } from "@babylonjs/core/Events/pointerEvents.js";
import type { ICanvasRenderingContext } from "@babylonjs/core/Engines/ICanvas.js";
/**
 * Class used to create radio button controls
 */
export declare class RadioButton extends Control {
    name?: string | undefined;
    private _isChecked;
    private _background;
    private _checkSizeRatio;
    private _thickness;
    /** Gets or sets border thickness */
    get thickness(): number;
    set thickness(value: number);
    /** Gets or sets group name */
    group: string;
    /** Observable raised when isChecked is changed */
    onIsCheckedChangedObservable: Observable<boolean>;
    /** Gets or sets a value indicating the ratio between overall size and check size */
    get checkSizeRatio(): number;
    set checkSizeRatio(value: number);
    /** Gets or sets background color */
    get background(): string;
    set background(value: string);
    /** Gets or sets a boolean indicating if the checkbox is checked or not */
    get isChecked(): boolean;
    set isChecked(value: boolean);
    /**
     * Creates a new RadioButton
     * @param name defines the control name
     */
    constructor(name?: string | undefined);
    protected _getTypeName(): string;
    _draw(context: ICanvasRenderingContext): void;
    _onPointerDown(target: Control, coordinates: Vector2, pointerId: number, buttonIndex: number, pi: PointerInfoBase): boolean;
    /**
     * Utility function to easily create a radio button with a header
     * @param title defines the label to use for the header
     * @param group defines the group to use for the radio button
     * @param isChecked defines the initial state of the radio button
     * @param onValueChanged defines the callback to call when value changes
     * @returns a StackPanel containing the radio button and a textBlock
     */
    static AddRadioButtonWithHeader(title: string, group: string, isChecked: boolean, onValueChanged: (button: RadioButton, value: boolean) => void): StackPanel;
}
