import { Vector3 } from "@babylonjs/core/Maths/math.vector.js";
import type { float } from "@babylonjs/core/types.js";
import { VolumeBasedPanel } from "./volumeBasedPanel.js";
import type { Control3D } from "./control3D.js";
/**
 * Class used to create a container panel deployed on the surface of a sphere
 */
export declare class SpherePanel extends VolumeBasedPanel {
    private _radius;
    /**
     * Gets or sets the radius of the sphere where to project controls (5 by default)
     */
    get radius(): float;
    set radius(value: float);
    protected _mapGridNode(control: Control3D, nodePosition: Vector3): void;
    private _sphericalMapping;
}
