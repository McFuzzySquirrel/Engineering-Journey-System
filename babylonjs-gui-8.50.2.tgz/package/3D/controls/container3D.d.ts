import type { Nullable } from "@babylonjs/core/types.js";
import { TransformNode } from "@babylonjs/core/Meshes/transformNode.js";
import type { Scene } from "@babylonjs/core/scene.js";
import { Control3D } from "./control3D.js";
/**
 * Class used to create containers for controls
 */
export declare class Container3D extends Control3D {
    private _blockLayout;
    /**
     * Gets the list of child controls
     */
    protected _children: Control3D[];
    /**
     * Gets the list of child controls
     */
    get children(): Array<Control3D>;
    /**
     * Gets or sets a boolean indicating if the layout must be blocked (default is false).
     * This is helpful to optimize layout operation when adding multiple children in a row
     */
    get blockLayout(): boolean;
    set blockLayout(value: boolean);
    /**
     * Creates a new container
     * @param name defines the container name
     */
    constructor(name?: string);
    /**
     * Force the container to update the layout. Please note that it will not take blockLayout property in account
     * @returns the current container
     */
    updateLayout(): Container3D;
    /**
     * Gets a boolean indicating if the given control is in the children of this control
     * @param control defines the control to check
     * @returns true if the control is in the child list
     */
    containsControl(control: Control3D): boolean;
    /**
     * Adds a control to the children of this control
     * @param control defines the control to add
     * @returns the current container
     */
    addControl(control: Control3D): Container3D;
    /**
     * This function will be called everytime a new control is added
     */
    protected _arrangeChildren(): void;
    protected _createNode(scene: Scene): Nullable<TransformNode>;
    /**
     * Removes a control from the children of this control
     * @param control defines the control to remove
     * @returns the current container
     */
    removeControl(control: Control3D): Container3D;
    protected _getTypeName(): string;
    /**
     * Releases all associated resources
     */
    dispose(): void;
    /** Control rotation will remain unchanged  */
    static readonly UNSET_ORIENTATION = 0;
    /** Control will rotate to make it look at sphere central axis */
    static readonly FACEORIGIN_ORIENTATION = 1;
    /** Control will rotate to make it look back at sphere central axis */
    static readonly FACEORIGINREVERSED_ORIENTATION = 2;
    /** Control will rotate to look at z axis (0, 0, 1) */
    static readonly FACEFORWARD_ORIENTATION = 3;
    /** Control will rotate to look at negative z axis (0, 0, -1) */
    static readonly FACEFORWARDREVERSED_ORIENTATION = 4;
}
