import { Vector3 } from "@babylonjs/core/Maths/math.vector.js";
import type { Control3D } from "./control3D.js";
import { VolumeBasedPanel } from "./volumeBasedPanel.js";
/**
 * Class used to create a container panel deployed on the surface of a plane
 */
export declare class PlanePanel extends VolumeBasedPanel {
    protected _mapGridNode(control: Control3D, nodePosition: Vector3): void;
}
